

```python
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error
import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd
import numpy as np
import datetime
%matplotlib inline
```

### Read and Import  the Database


```python
stocks = pd.read_csv(r"./databank/sphist.csv")
stocks["Date"] = pd.to_datetime(stocks["Date"])
stocks = stocks.sort_values(by="Date", ascending=True)

# Prepare a separate copy of the data frame to execute and protect the original data frame
shares = stocks.copy()
print(shares.head())
```

                Date   Open   High    Low  Close     Volume  Adj Close
    16589 1950-01-03  16.66  16.66  16.66  16.66  1260000.0      16.66
    16588 1950-01-04  16.85  16.85  16.85  16.85  1890000.0      16.85
    16587 1950-01-05  16.93  16.93  16.93  16.93  2550000.0      16.93
    16586 1950-01-06  16.98  16.98  16.98  16.98  2010000.0      16.98
    16585 1950-01-09  17.08  17.08  17.08  17.08  2520000.0      17.08
    

### Resetting the Database Index for ease of moving average calcs


```python
shares.reset_index(inplace=True, drop=True)
```

### Initializing new columns for the Database


```python
shares["Day_5"] = 0
shares["Day_30"] = 0
shares["Day_365"] = 0
shares["D30_D5"] = 0 
shares["D365_D30"] = 0
shares["Std_5"] = 0
shares["Std_30"] = 0
shares["Std_365"] = 0
shares["Std30_Std5"] = 0
shares["Std365_Std30"] = 0
```

#### Developing the Average Share Prices and Standard Deviations for the past 5 Days, 30 Days & 365 Days


```python
temp_val = list() 
# Number of training examples to be considered for the analysis based on moving average req't
no_days = [5, 30, 365]
m = shares.index[-1] - (max(no_days) - 1)

# Moving Average of Market Close for the past 5, 30, 365 days
for i in range(len(no_days)):
    j = shares.index[0]
    while j <= (m + no_days[i]):
        shares.loc[j, "Day_"+ str(no_days[i])] = np.mean(shares['Close'].loc[j + 1: j + no_days[i]])
        shares.loc[j, "Std_"+ str(no_days[i])] = np.std(shares['Close'].loc[j + 1: j + no_days[i]])
        j += 1
```

### Preparing new columns using the moving average & standard deviation Data


```python
shares["D30_D5"] = shares["Day_30"] / shares["Day_5"]
shares["D365_D30"] = shares["Day_365"] / shares["Day_30"]
shares["Std30_Std5"] = shares["Std_30"] / shares["Std_5"]
shares["Std365_Std30"] = shares["Std_365"] / shares["Std_30"]
```

### Checking the moving average, variance and new columns' output


```python
out_cols = ["Date", "Close", "Day_5", "Day_30", "Day_365", "Std_5", "Std_30", "Std_365", "D30_D5", "D365_D30", "Std30_Std5", "Std365_Std30"]
shares[out_cols].head(5)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Date</th>
      <th>Close</th>
      <th>Day_5</th>
      <th>Day_30</th>
      <th>Day_365</th>
      <th>Std_5</th>
      <th>Std_30</th>
      <th>Std_365</th>
      <th>D30_D5</th>
      <th>D365_D30</th>
      <th>Std30_Std5</th>
      <th>Std365_Std30</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1950-01-03</td>
      <td>16.66</td>
      <td>16.974</td>
      <td>16.990000</td>
      <td>19.462411</td>
      <td>0.079649</td>
      <td>0.186011</td>
      <td>1.786854</td>
      <td>1.000943</td>
      <td>1.145522</td>
      <td>2.335370</td>
      <td>9.606186</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1950-01-04</td>
      <td>16.85</td>
      <td>17.022</td>
      <td>16.994667</td>
      <td>19.476274</td>
      <td>0.060465</td>
      <td>0.184187</td>
      <td>1.786161</td>
      <td>0.998394</td>
      <td>1.146023</td>
      <td>3.046183</td>
      <td>9.697534</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1950-01-05</td>
      <td>16.93</td>
      <td>16.988</td>
      <td>17.002000</td>
      <td>19.489562</td>
      <td>0.120565</td>
      <td>0.185839</td>
      <td>1.785209</td>
      <td>1.000824</td>
      <td>1.146310</td>
      <td>1.541393</td>
      <td>9.606230</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1950-01-06</td>
      <td>16.98</td>
      <td>16.926</td>
      <td>17.009333</td>
      <td>19.502082</td>
      <td>0.175795</td>
      <td>0.189137</td>
      <td>1.783589</td>
      <td>1.004923</td>
      <td>1.146552</td>
      <td>1.075894</td>
      <td>9.430131</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1950-01-09</td>
      <td>17.08</td>
      <td>16.854</td>
      <td>17.012333</td>
      <td>19.513617</td>
      <td>0.171651</td>
      <td>0.190940</td>
      <td>1.781500</td>
      <td>1.009394</td>
      <td>1.147028</td>
      <td>1.112370</td>
      <td>9.330180</td>
    </tr>
  </tbody>
</table>
</div>



### Get the Feel About the Target Column 


```python
plt.plot(shares['Date'], shares['Close'])
plt.show()
```


![png](output_14_0.png)


### Converting the datetime data of Date column into meaningful numeric form for regression


```python
# Feature Scaling for Logistic Regression

dy_sc = []
dy_sc.clear()
dt_min = min(shares['Date'])
dt_max = max(shares['Date'])

for i in range(len(shares['Date'])):
    dy_sc.append((shares['Date'][i] - dt_min)/(dt_max-dt_min))
shares['Days'] = dy_sc
print("\n Date Scaling Vector:\n", shares['Days'].iloc[0:10])
```

    
     Date Scaling Vector:
     0    0.000000
    1    0.000042
    2    0.000083
    3    0.000125
    4    0.000249
    5    0.000291
    6    0.000332
    7    0.000374
    8    0.000415
    9    0.000540
    Name: Days, dtype: float64
    
The 365 Days moving average uses the data for the past one year. This  generates null values in average and std deviation columns for the last 365 days of the data. Let's remove  all rows with data pertaining to the last year (i.e. prior to 3rd January 1951)

```python
shares = shares.loc[:m]
shares.dropna(axis=0, how="any")
print(shares.isnull().sum().sum())
```

    0
    

### Feature Correlation Matrix to understand predictive target influence


```python
all_cols = shares.columns.values
corrmat = shares.corr()
corrmat = corrmat[corrmat >= 0.3]
print("\n Correlation Matrix: \n", corrmat['Close'])
print("\n Correlation Heatmap\n")
sns.heatmap(corrmat)
plt.show()
```

    
     Correlation Matrix: 
     Open            0.999892
    High            0.999950
    Low             0.999952
    Close           1.000000
    Volume          0.755750
    Adj Close       1.000000
    Day_5           0.999784
    Day_30          0.999128
    Day_365         0.987509
    D30_D5               NaN
    D365_D30             NaN
    Std_5           0.735871
    Std_30          0.796776
    Std_365         0.871603
    Std30_Std5           NaN
    Std365_Std30         NaN
    Days            0.868305
    Name: Close, dtype: float64
    
     Correlation Heatmap
    
    


![png](output_20_1.png)

Since some of the features are developed by manipulating the existing data values, their standard deviation will be zero. That makes the corresponding correlation matrix values as NaN above.
### Preparing Features List per Influential Significance


```python
feature = ['Adj Close', 'Low', 'High',  'Open',  'Day_365', 'Days', 'Day_30', 'Day_5', 'Std_365', 'Volume', 'Std_30', 'Std_5']
target = ["Close"]
```

### Extracting the Training / Test / Cross-Validation Sets


```python
# Split Training/Test/CV set 60/20/20

train_set = shares[shares["Date"] > '1976-06-23']
test_set = shares[(shares["Date"] <= '1976-06-23') & (shares["Date"] > '1963-03-19')]
cross_val = shares[shares["Date"] <= '1963-03-19']
```

### Develop Linear Regression and Train it over the Training Set


```python
train_feature = train_set[feature]
train_target = train_set[target]

lrr = LinearRegression()
lrr.fit(train_feature, train_target)
predictions_train = lrr.predict(train_feature)
mse_train = mean_absolute_error(predictions_train, train_target)

print("\n MAE for training set =", mse_train)
```

    
     MAE for training set = 1.0738542107308132e-10
    

### Compare Model Fit Over Training Set


```python
fig = plt.figure(figsize=(20,6))

for i in range(2):
    ax = fig.add_subplot(1, 2, i+1)
    if i == 0:
        plt.plot(train_set['Date'], train_target, c='black')
        plt.title('Actual S&P500 Index')
    else:
        plt.plot(train_set['Date'], predictions_train, c='red')
        plt.title('Learning Algorithm Prediction Over Training Set')
    plt.xlabel('Years')
    plt.ylabel('S&P500 Index')
    
plt.show()
```


![png](output_29_0.png)

The above graph shows model overfitting on the training set.
### Verify the Learning Algorithm over the Test Set


```python
test_feature = test_set[feature]
test_target = test_set[target]

lrr = LinearRegression()
lrr.fit(train_feature, train_target)
predictions_test = lrr.predict(test_feature)
mse_test = mean_absolute_error(predictions_test, test_target)

print("\n MAE for test set =", mse_test)
```

    
     MAE for test set = 1.0190167911144772e-10
    

### Compare Prediction Error over Test Set


```python
fig = plt.figure(figsize=(20,6))

for i in range(2):
    ax = fig.add_subplot(1, 2, i+1)
    if i == 0:
        plt.plot(test_set['Date'], test_target, c='blue')
        plt.title('Actual S&P500 Index')
    else:
        plt.plot(test_set['Date'], predictions_test, c='green')
        plt.title('Learning Algorithm Prediction Over Test Set')
    plt.xlabel('Years')
    plt.ylabel('Closing S&P500 Index')
    
plt.show()
```


![png](output_34_0.png)


The above graph shows how closely the model predicted over the test set.

### Checking the Learning Algorithm Predictibility on Cross-Validation set 


```python
train_feature = train_set[feature]
train_target = train_set[target]
cv_feature =cross_val[feature]
cv_target = cross_val[target]

lrr = LinearRegression()
lrr.fit(train_feature, train_target)
predictions_cv = lrr.predict(cv_feature)
mse_cv = mean_absolute_error(predictions_cv, cv_target)

print("\n MAE for cross-validation set =", mse_cv)
```

    
     MAE for cross-validation set = 1.0219626343663962e-10
    

### Model Prediction Comparison over Cross-Validation Set


```python
fig = plt.figure(figsize=(20,6))

for i in range(2):
    ax = fig.add_subplot(1, 2, i+1)
    if i == 0:
        plt.plot(cross_val['Date'], cv_target, c='purple')
        plt.title('Actual S&P500 Index')
    else:
        plt.plot(cross_val['Date'], predictions_cv, c='cyan')
        plt.title('Learning Algorithm Prediction Over Cross-Validation Set')
    plt.xlabel('Years')
    plt.ylabel('Closing S&P500 Index')
    
plt.show()
```


![png](output_39_0.png)


Model predicted closely with the actual S&P500 Index movement while tested over the unknown cross-validation data.

### Conclusion
* The model algorithm gets trained well over the training set as it reflects by zero MAE.

* The learning algorithm predicted very good while tested over the Test Set.

* The model generalization and predictability over any unknown data set seems very satisfactory as its MAE over the cross-validation set remains in parity with the MAEs over the Training Set and the Test Set.